<?php

namespace App\Http\Controllers;

use App\Models\Rendelesek;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class RendelesekController extends Controller
{
    public function index()
    {
        return Rendelesek::all();
    }

    public function store(Request $request){
        $validator=Validator::make($request->all(),
        [
            'felhasznalo_id'=>'required',
            'felhasznalo'=>'required',
            'allapot'=>'required',
            'fizetesi_mod'=>'required',
            'szallitasi_cim'=>'required'
        ]);

        if($validator->fails()){
            return response()->json(["Hiba!"=>"Legalább egy elemet kihagytál!"],401);
        }

        $rendelesek=Rendelesek::create($request->all());
        return response()->json(["Sikeres feltöltés"],201);

    }

    
    public function update (Request $request, $id)
    {
        $rendelesek = Rendelesek::find($id);
        if(is_null($rendelesek))
            return response()->json(['Azonosító hiba:' =>'Nincs ilyen id-jű sor az adattáblában'],417);

        $validator = Validator::make($request->all(),
        [
            'felhasznalo_id'=>'required',
            'felhasznalo'=>'required',
            'allapot'=>'required',
            'fizetesi_mod'=>'required',
            'szallitasi_cim'=>'required'
        ]);

        if($validator->fails())
        {
            return response()->json(['Adat hiba'=>'Fontos adar hiányzik, nem lehet frissíteni'],410);
        }

        $rendelesek -> update($request->all());
        return response()->json(['A következő id-jű rendelések változtak'=>$rendelesek->id],202);
    }

    public function destroy($id)
    {
        $rendelesek = Rendelesek::find($id);
        if(is_null($rendelesek))
             return response()->json(['Azonosító hiba:' =>'Nincs ilyen id-jű sor az adattáblában'],417);
            $rendelesek->delete();
            return response('',203);
    }

    public function getById($id){
        $rendelesek = Rendelesek::find($id);
        if(is_null($rendelesek)){
            return response()->json(['Azonosító hiba:'=>'Nincs ilyen id-jű sor az adatbázisban'],417);
        }
        else{
            return response()->json($rendelesek, 202);
        }
    }
}
