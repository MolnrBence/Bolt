<?php

namespace App\Http\Controllers;

use App\Models\Termekek;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class TermekekController extends Controller
{
    public function index()
    {
        return Termekek::all();
    }

    public function store(Request $request){
        $validator=Validator::make($request->all(),
        [
            'cim'=>'required',
            'szerzo'=>'required',
            'kategoria'=>'required',
            'kiado'=>'required',
            'keszlet'=>'required'
        ]);

        if($validator->fails()){
            return response()->json(["Hiba!"=>"Legalább egy elemet kihagytál!"],401);
        }

        $termekek=Termekek::create($request->all());
        return response()->json(["Sikeres feltöltés"],201);

    }

    
    public function update (Request $request, $id)
    {
        $termekek = Termekek::find($id);
        if(is_null($termekek))
            return response()->json(['Azonosító hiba:' =>'Nincs ilyen id-jű sor az adattáblában'],417);

        $validator = Validator::make($request->all(),
        [
            'cim'=>'required',
            'szerzo'=>'required',
            'kategoria'=>'required',
            'kiado'=>'required',
            'keszlet'=>'required'
        ]);

        if($validator->fails())
        {
            return response()->json(['Adat hiba'=>'Fontos adar hiányzik, nem lehet frissíteni'],410);
        }

        $termekek -> update($request->all());
        return response()->json(['A következő id-jű rendelés tételek változtak'=>$termekek->id],202);
    }

    public function destroy($id)
    {
        $termekek = Termekek::find($id);
        if(is_null($termekek))
             return response()->json(['Azonosító hiba:' =>'Nincs ilyen id-jű sor az adattáblában'],417);
            $termekek->delete();
            return response('',203);
    }

    public function getById($id){
        $termekek = Termekek::find($id);
        if(is_null($termekek)){
            return response()->json(['Azonosító hiba:'=>'Nincs ilyen id-jű sor az adatbázisban'],417);
        }
        else{
            return response()->json($termekek, 202);
        }
    }

    public function getExpensiverThan($ar){
        $termekek = Termekek::where('ar','>',$ar);
        if($termekek->exists()){
            return $termekek->get();
        }
        else{
            return response()->json(['Hiba:'=>'Nem található az adott értéktől drágább termék'],407);
        }
    }

    public function getCheaperThan($ar){
        $termekek = Termekek::where('ar','<',$ar);
        if($termekek->exists()){
            return $termekek->get();
        }
        else{
            return response()->json(['Hiba:'=>'Nem található az adott értéktől olcsóbb termék'],407);
        }
    }
}
