<?php

namespace App\Http\Controllers;

use App\Models\Ertekelesek;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ErtekelesekController extends Controller
{
    public function index()
    {
        return Ertekelesek::all();
    }

    public function store(Request $request){
        $validator=Validator::make($request->all(),
        [
            'felhasznalo' => 'required',
            'termek' => 'required',
            'felhasznalo_id' => 'required',
            'termek_id' => 'required',
            'szoveg' => 'required'
        ]);

        if($validator->fails()){
            return response()->json(["Hiba!"=>"Legalább egy elemet kihagytál!"],401);
        }

        $ertekelesek=Ertekelesek::create($request->all());
        return response()->json(["Sikeres feltöltés"],201);

    }
    
    public function update (Request $request, $id)
    {
        $ertekelesek = Ertekelesek::find($id);
        if(is_null($ertekelesek))
            return response()->json(['Azonosító hiba:' =>'Nincs ilyen id-jű sor az adattáblában'],417);

        $validator = Validator::make($request->all(),
        [
            'felhasznalo' => 'required',
            'termek' => 'required',
            'felhasznalo_id' => 'required',
            'termek_id' => 'required',
            'szoveg' => 'required'
        ]);

        if($validator->fails())
        {
            return response()->json(['Adat hiba'=>'Fontos adar hiányzik, nem lehet frissíteni'],410);
        }

        $ertekelesek -> update($request->all());
        return response()->json(['A következő értékelések változtak'=>$ertekelesek->id],202);
    }

    public function destroy($id)
    {
        $ertekelesek = Ertekelesek::find($id);
        if(is_null($ertekelesek))
             return response()->json(['Azonosító hiba:' =>'Nincs ilyen id-jű sor az adattáblában'],417);
            $ertekelesek->delete();
            return response('',203);
    }

    public function getById($id){
        $ertekelesek = Ertekelesek::find($id);
        if(is_null($ertekelesek)){
            return response()->json(['Azonosító hiba:'=>'Nincs ilyen id-jű sor az adatbázisban'],417);
        }
        else{
            return response()->json($ertekelesek, 202);
        }
    }


}
