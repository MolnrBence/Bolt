<?php

namespace App\Http\Controllers;

use App\Models\Felhasznalok;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class FelhasznalokController extends Controller
{

    public function index()
    {
        return Felhasznalok::all();
    }

    public function store(Request $request){
        $validator=Validator::make($request->all(),
        [
            'nev'=>'required',
            'email'=>'required',
            'jelszo'=>'required',
            'telefonszam'=>'required'
        ]);

        if($validator->fails()){
            return response()->json(["Hiba!"=>"Legalább egy elemet kihagytál!"],401);
        }

        $felhasznalok=Felhasznalok::create($request->all());
        return response()->json(["Sikeres feltöltés"],201);

    }

    
    public function update (Request $request, $id)
    {
        $felhasznalok = Felhasznalok::find($id);
        if(is_null($felhasznalok))
            return response()->json(['Azonosító hiba:' =>'Nincs ilyen id-jű sor az adattáblában'],417);

        $validator = Validator::make($request->all(),
        [
            'nev'=>'required',
            'email'=>'required',
            'jelszo'=>'required',
            'telefonszam'=>'required'
        ]);

        if($validator->fails())
        {
            return response()->json(['Adat hiba'=>'Fontos adar hiányzik, nem lehet frissíteni'],410);
        }

        $felhasznalok -> update($request->all());
        return response()->json(['A következő nevű felhasználók változtak'=>$felhasznalok->nev],202);
    }

    public function destroy($id)
    {
        $felhasznalok = Felhasznalok::find($id);
        if(is_null($felhasznalok))
             return response()->json(['Azonosító hiba:' =>'Nincs ilyen id-jű sor az adattáblában'],417);
            $felhasznalok->delete();
            return response('',203);
    }

    public function getById($id){
        $felhasznalok = Felhasznalok::find($id);
        if(is_null($felhasznalok)){
            return response()->json(['Azonosító hiba:'=>'Nincs ilyen id-jű sor az adatbázisban'],417);
        }
        else{
            return response()->json($felhasznalok, 202);
        }
    }

}
