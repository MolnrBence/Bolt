<?php

namespace App\Http\Controllers;

use App\Models\Kreditek;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class KreditekController extends Controller
{
    public function index()
    {
        return Kreditek::all();
    }

    public function store(Request $request){
        $validator=Validator::make($request->all(),
        [
            'felhasznalo'=>'required',
            'felhasznalo_id'=>'required',
            'egyenleg'=>'required'
        ]);

        if($validator->fails()){
            return response()->json(["Hiba!"=>"Legalább egy elemet kihagytál!"],401);
        }

        $kreditek=Kreditek::create($request->all());
        return response()->json(["Sikeres feltöltés"],201);

    }

    
    public function update (Request $request, $id)
    {
        $kreditek = Kreditek::find($id);
        if(is_null($kreditek))
            return response()->json(['Azonosító hiba:' =>'Nincs ilyen id-jű sor az adattáblában'],417);

        $validator = Validator::make($request->all(),
        [
            'felhasznalo'=>'required',
            'felhasznalo_id'=>'required',
            'egyenleg'=>'required'
        ]);

        if($validator->fails())
        {
            return response()->json(['Adat hiba'=>'Fontos adar hiányzik, nem lehet frissíteni'],410);
        }

        $kreditek -> update($request->all());
        return response()->json(['A következő id-jű kreditek változtak'=>$kreditek->id],202);
    }

    public function destroy($id)
    {
        $kreditek = Kreditek::find($id);
        if(is_null($kreditek))
             return response()->json(['Azonosító hiba:' =>'Nincs ilyen id-jű sor az adattáblában'],417);
            $kreditek->delete();
            return response('',203);
    }

    public function getById($id){
        $kreditek = Kreditek::find($id);
        if(is_null($kreditek)){
            return response()->json(['Azonosító hiba:'=>'Nincs ilyen id-jű sor az adatbázisban'],417);
        }
        else{
            return response()->json($kreditek, 202);
        }
    }
}
