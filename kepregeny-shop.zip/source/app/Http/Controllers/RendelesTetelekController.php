<?php

namespace App\Http\Controllers;

use App\Models\Rendeles_Tetelek;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class RendelesTetelekController extends Controller
{
    public function index()
    {
        return Rendeles_Tetelek::all();
    }

    public function store(Request $request){
        $validator=Validator::make($request->all(),
        [
            'termek'=>'required',
            'rendeles'=>'required',
            'rendeles_id'=>'required',
            'termek_id'=>'required',
            'mennyiseg'=>'required',
            'egysegar'=>'required'
        ]);

        if($validator->fails()){
            return response()->json(["Hiba!"=>"Legalább egy elemet kihagytál!"],401);
        }

        $rendeles_Tetelek=Rendeles_Tetelek::create($request->all());
        return response()->json(["Sikeres feltöltés"],201);

    }

    
    public function update (Request $request, $id)
    {
        $rendeles_Tetelek = Rendeles_Tetelek::find($id);
        if(is_null($rendeles_Tetelek))
            return response()->json(['Azonosító hiba:' =>'Nincs ilyen id-jű sor az adattáblában'],417);

        $validator = Validator::make($request->all(),
        [
            'termek'=>'required',
            'rendeles'=>'required',
            'rendeles_id'=>'required',
            'termek_id'=>'required',
            'mennyiseg'=>'required',
            'egysegar'=>'required'
        ]);

        if($validator->fails())
        {
            return response()->json(['Adat hiba'=>'Fontos adar hiányzik, nem lehet frissíteni'],410);
        }

        $rendeles_Tetelek -> update($request->all());
        return response()->json(['A következő id-jű rendelés tételek változtak'=>$rendeles_Tetelek->id],202);
    }

    public function destroy($id)
    {
        $rendeles_Tetelek = Rendeles_Tetelek::find($id);
        if(is_null($rendeles_Tetelek))
             return response()->json(['Azonosító hiba:' =>'Nincs ilyen id-jű sor az adattáblában'],417);
            $rendeles_Tetelek->delete();
            return response('',203);
    }

    public function getById($id){
        $rendeles_Tetelek = Rendeles_Tetelek::find($id);
        if(is_null($rendeles_Tetelek)){
            return response()->json(['Azonosító hiba:'=>'Nincs ilyen id-jű sor az adatbázisban'],417);
        }
        else{
            return response()->json($rendeles_Tetelek, 202);
        }
    }
}
