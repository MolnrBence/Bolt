<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Rendelesek extends Model
{
    use HasFactory;
    public $table = 'rendelesek';
    public $timestamps = false;
    public $guarded=[];
}
