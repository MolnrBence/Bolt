<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\FelhasznalokController;
use App\Http\Controllers\TermekekController;
use App\Http\Controllers\RendelesekController;
use App\Http\Controllers\RendelesTetelekController;
use App\Http\Controllers\ErtekelesekController;
use App\Http\Controllers\KreditekController;

Route::get('/felhasznalok',[FelhasznalokController::class,'index']);
Route::post('/felhasznalok',[FelhasznalokController::class,'store']);
Route::put('/felhasznalok/{id}',[FelhasznalokController::class,'update']);
Route::delete('/felhasznalok/{id}',[FelhasznalokController::class,'destroy']);
Route::get('/felhasznalok/{id}',[FelhasznalokController::class,'getById']);

///

Route::get('/termekek',[TermekekController::class,'index']);
Route::post('/termekek',[TermekekController::class,'store']);
Route::put('/termekek/{id}',[TermekekController::class,'update']);
Route::delete('/termekek/{id}',[TermekekController::class,'destroy']);
Route::get('/termekek/{id}',[TermekekController::class,'getById']);
Route::get('/termekek/expensiver/{ar}',[TermekekController::class,'getExpensiverThan']);
Route::get('/termekek/cheaper/{ar}',[TermekekController::class,'getCheaperThan']);

///

Route::get('/rendelesek',[RendelesekController::class,'index']);
Route::post('/rendelesek',[RendelesekController::class,'store']);
Route::put('/rendelesek/{id}',[RendelesekController::class,'update']);
Route::delete('/rendelesek/{id}',[RendelesekController::class,'destroy']);
Route::get('/rendelesek/{id}',[RendelesekController::class,'getById']);

///

Route::get('/rendelesTetelek',[RendelesTetelekController::class,'index']);
Route::post('/rendelesTetelek',[RendelesTetelekController::class,'store']);
Route::put('/rendelesTetelek/{id}',[RendelesTetelekController::class,'update']);
Route::delete('/rendelesTetelek/{id}',[RendelesTetelekController::class,'destroy']);
Route::get('/rendelesTetelek/{id}',[RendelesTetelekController::class,'getById']);

///

Route::get('/ertekelesek',[ErtekelesekController::class,'index']);
Route::post('/ertekelesek',[ErtekelesekController::class,'store']);
Route::put('/ertekelesek/{id}',[ErtekelesekController::class,'update']);
Route::delete('/ertekelesek/{id}',[ErtekelesekController::class,'destroy']);
Route::get('/ertekelesek/{id}',[ErtekelesekController::class,'getById']);

///

Route::get('/kreditek',[KreditekController::class,'index']);
Route::post('/kreditek',[KreditekController::class,'store']);
Route::put('/kreditek/{id}',[KreditekController::class,'update']);
Route::delete('/kreditek/{id}',[KreditekController::class,'destroy']);
Route::get('/kreditek/{id}',[KreditekController::class,'getById']);

///