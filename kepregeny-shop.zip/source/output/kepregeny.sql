-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 21, 2025 at 07:43 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kepregeny`
--

-- --------------------------------------------------------

--
-- Table structure for table `ertekelesek`
--

CREATE TABLE `ertekelesek` (
  `ertekeles_id` int(11) NOT NULL,
  `felhasznalo_id` int(11) NOT NULL,
  `termek_id` int(11) NOT NULL,
  `ertekeles` int(11) DEFAULT NULL CHECK (`ertekeles` between 1 and 5),
  `szoveg` text DEFAULT NULL,
  `datum` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- Dumping data for table `ertekelesek`
--

INSERT INTO `ertekelesek` (`ertekeles_id`, `felhasznalo_id`, `termek_id`, `ertekeles`, `szoveg`, `datum`) VALUES
(1, 1, 1, 5, 'Nagyon jó kezdés, izgalmas sztori.', '2025-11-21 19:41:23'),
(2, 2, 2, 4, 'One Piece mindig hozza a szintet!', '2025-11-21 19:41:23'),
(3, 3, 3, 5, 'A Démonölő széria csúcsminőség!', '2025-11-21 19:41:23'),
(4, 4, 4, 5, 'Attack on Titan elképesztően jó!', '2025-11-21 19:41:23'),
(5, 1, 6, 3, 'Jó, de túl rövid volt.', '2025-11-21 19:41:23');

-- --------------------------------------------------------

--
-- Table structure for table `felhasznalok`
--

CREATE TABLE `felhasznalok` (
  `felhasznalo_id` int(11) NOT NULL,
  `nev` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `jelszo` varchar(255) NOT NULL,
  `telefonszam` varchar(20) DEFAULT NULL,
  `regisztracio_datum` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- Dumping data for table `felhasznalok`
--

INSERT INTO `felhasznalok` (`felhasznalo_id`, `nev`, `email`, `jelszo`, `telefonszam`, `regisztracio_datum`) VALUES
(1, 'Tóth Gergely', 'toth.gergely@example.com', 'jelszo123', '06201234567', '2025-11-21 19:41:23'),
(2, 'Varga Eszter', 'eszter.varga@example.com', 'titok456', '06203334455', '2025-11-21 19:41:23'),
(3, 'Horváth Márk', 'mark.horvath@example.com', 'animefan99', '06207778899', '2025-11-21 19:41:23'),
(4, 'Kovács Réka', 'reka.kovacs@example.com', 'securePass', NULL, '2025-11-21 19:41:23'),
(5, 'Farkas Bence', 'bence.farkas@example.com', 'mangaKing12', '06201112233', '2025-11-21 19:41:23');

-- --------------------------------------------------------

--
-- Table structure for table `kreditek`
--

CREATE TABLE `kreditek` (
  `kredit_id` int(11) NOT NULL,
  `felhasznalo_id` int(11) NOT NULL,
  `egyenleg` int(11) DEFAULT 0,
  `frissitve` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- Dumping data for table `kreditek`
--

INSERT INTO `kreditek` (`kredit_id`, `felhasznalo_id`, `egyenleg`, `frissitve`) VALUES
(1, 1, 100, '2025-11-21 19:41:23'),
(2, 2, 240, '2025-11-21 19:41:23'),
(3, 3, 80, '2025-11-21 19:41:23'),
(4, 4, 150, '2025-11-21 19:41:23'),
(5, 5, 60, '2025-11-21 19:41:23');

-- --------------------------------------------------------

--
-- Table structure for table `rendelesek`
--

CREATE TABLE `rendelesek` (
  `rendeles_id` int(11) NOT NULL,
  `felhasznalo_id` int(11) NOT NULL,
  `rendeles_datum` datetime DEFAULT current_timestamp(),
  `allapot` varchar(30) DEFAULT 'Függőben',
  `fizetesi_mod` varchar(30) DEFAULT NULL,
  `szallitasi_cim` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- Dumping data for table `rendelesek`
--

INSERT INTO `rendelesek` (`rendeles_id`, `felhasznalo_id`, `rendeles_datum`, `allapot`, `fizetesi_mod`, `szallitasi_cim`) VALUES
(1, 1, '2025-11-21 19:41:23', 'Függőben', 'Bankkártya', 'Budapest, Andrássy út 14.'),
(2, 3, '2025-11-21 19:41:23', 'Függőben', 'Utánvét', 'Győr, Bajcsy-Zsilinszky út 55.'),
(3, 2, '2025-11-21 19:41:23', 'Függőben', 'PayPal', 'Pécs, Király utca 8.'),
(4, 4, '2025-11-21 19:41:23', 'Függőben', 'Bankkártya', 'Szeged, Fő tér 22.');

-- --------------------------------------------------------

--
-- Table structure for table `rendeles_tetelek`
--

CREATE TABLE `rendeles_tetelek` (
  `tetel_id` int(11) NOT NULL,
  `rendeles_id` int(11) NOT NULL,
  `termek_id` int(11) NOT NULL,
  `mennyiseg` int(11) NOT NULL,
  `egysegar` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- Dumping data for table `rendeles_tetelek`
--

INSERT INTO `rendeles_tetelek` (`tetel_id`, `rendeles_id`, `termek_id`, `mennyiseg`, `egysegar`) VALUES
(1, 1, 1, 2, 2990),
(2, 1, 6, 1, 5990),
(3, 2, 3, 1, 3490),
(4, 3, 5, 3, 3590),
(5, 4, 2, 1, 3290),
(6, 4, 7, 1, 5490);

-- --------------------------------------------------------

--
-- Table structure for table `termekek`
--

CREATE TABLE `termekek` (
  `termek_id` int(11) NOT NULL,
  `cim` varchar(150) NOT NULL,
  `szerzo` varchar(100) DEFAULT NULL,
  `kategoria` varchar(50) DEFAULT NULL,
  `kiado` varchar(100) DEFAULT NULL,
  `ar` int(11) NOT NULL,
  `keszlet` int(11) DEFAULT 0,
  `borito_kep` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- Dumping data for table `termekek`
--

INSERT INTO `termekek` (`termek_id`, `cim`, `szerzo`, `kategoria`, `kiado`, `ar`, `keszlet`, `borito_kep`) VALUES
(1, 'Naruto 1. kötet', 'Masashi Kishimoto', 'Manga', 'Viz Media', 2990, 20, 'naruto1.jpg'),
(2, 'One Piece 12. kötet', 'Eiichiro Oda', 'Manga', 'Shueisha', 3290, 15, 'onepiece12.jpg'),
(3, 'Démonölő 4. kötet', 'Koyoharu Gotouge', 'Manga', 'Shueisha', 3490, 10, 'demonolo4.jpg'),
(4, 'Attack on Titan 3. kötet', 'Hajime Isayama', 'Manga', 'Kodansha', 3790, 12, 'aot3.jpg'),
(5, 'My Hero Academia 7. kötet', 'Kohei Horikoshi', 'Manga', 'Shueisha', 3590, 18, 'mha7.jpg'),
(6, 'Batman: Killing Joke', 'Alan Moore', 'Comic', 'DC Comics', 5990, 5, 'killing_joke.jpg'),
(7, 'Superman: Red Son', 'Mark Millar', 'Comic', 'DC Comics', 5490, 7, 'red_son.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ertekelesek`
--
ALTER TABLE `ertekelesek`
  ADD PRIMARY KEY (`ertekeles_id`),
  ADD KEY `felhasznalo_id` (`felhasznalo_id`),
  ADD KEY `termek_id` (`termek_id`);

--
-- Indexes for table `felhasznalok`
--
ALTER TABLE `felhasznalok`
  ADD PRIMARY KEY (`felhasznalo_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `kreditek`
--
ALTER TABLE `kreditek`
  ADD PRIMARY KEY (`kredit_id`),
  ADD KEY `felhasznalo_id` (`felhasznalo_id`);

--
-- Indexes for table `rendelesek`
--
ALTER TABLE `rendelesek`
  ADD PRIMARY KEY (`rendeles_id`),
  ADD KEY `felhasznalo_id` (`felhasznalo_id`);

--
-- Indexes for table `rendeles_tetelek`
--
ALTER TABLE `rendeles_tetelek`
  ADD PRIMARY KEY (`tetel_id`),
  ADD KEY `rendeles_id` (`rendeles_id`),
  ADD KEY `termek_id` (`termek_id`);

--
-- Indexes for table `termekek`
--
ALTER TABLE `termekek`
  ADD PRIMARY KEY (`termek_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ertekelesek`
--
ALTER TABLE `ertekelesek`
  MODIFY `ertekeles_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `felhasznalok`
--
ALTER TABLE `felhasznalok`
  MODIFY `felhasznalo_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `kreditek`
--
ALTER TABLE `kreditek`
  MODIFY `kredit_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `rendelesek`
--
ALTER TABLE `rendelesek`
  MODIFY `rendeles_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `rendeles_tetelek`
--
ALTER TABLE `rendeles_tetelek`
  MODIFY `tetel_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `termekek`
--
ALTER TABLE `termekek`
  MODIFY `termek_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ertekelesek`
--
ALTER TABLE `ertekelesek`
  ADD CONSTRAINT `ertekelesek_ibfk_1` FOREIGN KEY (`felhasznalo_id`) REFERENCES `felhasznalok` (`felhasznalo_id`),
  ADD CONSTRAINT `ertekelesek_ibfk_2` FOREIGN KEY (`termek_id`) REFERENCES `termekek` (`termek_id`);

--
-- Constraints for table `kreditek`
--
ALTER TABLE `kreditek`
  ADD CONSTRAINT `kreditek_ibfk_1` FOREIGN KEY (`felhasznalo_id`) REFERENCES `felhasznalok` (`felhasznalo_id`);

--
-- Constraints for table `rendelesek`
--
ALTER TABLE `rendelesek`
  ADD CONSTRAINT `rendelesek_ibfk_1` FOREIGN KEY (`felhasznalo_id`) REFERENCES `felhasznalok` (`felhasznalo_id`);

--
-- Constraints for table `rendeles_tetelek`
--
ALTER TABLE `rendeles_tetelek`
  ADD CONSTRAINT `rendeles_tetelek_ibfk_1` FOREIGN KEY (`rendeles_id`) REFERENCES `rendelesek` (`rendeles_id`),
  ADD CONSTRAINT `rendeles_tetelek_ibfk_2` FOREIGN KEY (`termek_id`) REFERENCES `termekek` (`termek_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
