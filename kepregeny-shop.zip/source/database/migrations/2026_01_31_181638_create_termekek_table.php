<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('termekek', function (Blueprint $table) {
            $table->id('termek_id');
            $table->string('cim');
            $table->string('szerzo');
            $table->string('kategoria');
            $table->string('kiado');
            $table->integer('ar') -> nullbale();
            $table->integer('keszlet');
            $table->string('borito_kep') -> nullbale();

        });
    }
    public function down(): void
    {
        Schema::dropIfExists('termekek');
    }
};