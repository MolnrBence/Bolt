<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('rendelesek', function (Blueprint $table) 
        {
            $table->id('rendeles_id');
            $table->unsignedBigInteger('felhasznalo_id');
            $table->timestamp('rendeles_datum')->useCurrent();
            $table->string('allapot')->default('Függőben');
            $table->string('fizetesi_mod');
            $table->string('szallitasi_cim');
            $table->foreign('felhasznalo_id')->references('felhasznalo_id')->on('felhasznalok')->onDelete('cascade');
        });
    }
    public function down(): void
    {
        Schema::dropIfExists('rendelesek');
    }
};
