<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
      Schema::create('kreditek', function (Blueprint $table) 
      {
            $table->id('kredit_id');
            $table->unsignedBigInteger('felhasznalo_id');
            $table->integer('egyenleg')->default(0);
            $table->timestamp('frissitve')->useCurrent();
            $table->foreign('felhasznalo_id')->references('felhasznalo_id')->on('felhasznalok')->onDelete('cascade');
        });
    }
    public function down(): void
    {
        Schema::dropIfExists('kreditek');
    }
};