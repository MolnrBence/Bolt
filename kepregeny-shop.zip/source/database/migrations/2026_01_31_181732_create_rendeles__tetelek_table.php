<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
       Schema::create('rendeles_tetelek', function (Blueprint $table) 
       {
            $table->id('tetel_id');
            $table->unsignedBigInteger('rendeles_id');
            $table->unsignedBigInteger('termek_id');
            $table->integer('mennyiseg');
            $table->integer('egysegar');
            $table->foreign('rendeles_id')->references('rendeles_id')->on('rendelesek')->onDelete('cascade');
            $table->foreign('termek_id')->references('termek_id')->on('termekek')->onDelete('cascade');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('rendeles_tetelek');
    }
};
