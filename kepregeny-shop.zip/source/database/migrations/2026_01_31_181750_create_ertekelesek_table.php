<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('ertekelesek', function (Blueprint $table) 
        {
            $table->id('ertekeles_id');
            $table->unsignedBigInteger('felhasznalo_id');
            $table->unsignedBigInteger('termek_id');
            $table->integer('ertekeles');
            $table->text('szoveg')->nullable();
            $table->timestamp('datum')->useCurrent();
            $table->foreign('felhasznalo_id')->references('felhasznalo_id')->on('felhasznalok')->onDelete('cascade');
            $table->foreign('termek_id')->references('termek_id')->on('termekek')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('ertekelesek');
    }
};
