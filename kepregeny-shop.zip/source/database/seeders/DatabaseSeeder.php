<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        DB::statement('SET FOREIGN_KEY_CHECKS=0;');

        DB::table('ertekelesek')->truncate();
        DB::table('rendeles_tetelek')->truncate();
        DB::table('rendelesek')->truncate();
        DB::table('kreditek')->truncate();
        DB::table('termekek')->truncate();
        DB::table('felhasznalok')->truncate();

        DB::statement('SET FOREIGN_KEY_CHECKS=1;');

        DB::table('felhasznalok')->insert([
            ['nev'=>'Tóth Gergely','email'=>'toth.gergely@gmai.com','jelszo'=>'jelszo123','telefonszam'=>'06201234567'],
            ['nev'=>'Varga Eszter','email'=>'eszter.varga@gmail.com','jelszo'=>'titok456','telefonszam'=>'06203334455'],
            ['nev'=>'Horváth Márk','email'=>'mark.horvath@gmail.com','jelszo'=>'animefan99','telefonszam'=>'06207778899'],
            ['nev'=>'Kovács Réka','email'=>'reka.kovacs@gmail.com','jelszo'=>'securePass','telefonszam'=>null],
            ['nev'=>'Farkas Bence','email'=>'bence.farkas@gmail.com','jelszo'=>'mangaKing12','telefonszam'=>'06201112233'],
        ]);

        DB::table('termekek')->insert([
            ['cim'=>'Naruto 1. kötet','szerzo'=>'Masashi Kishimoto','kategoria'=>'Manga','kiado'=>'Viz Media','ar'=>2990,'keszlet'=>20,'borito_kep'=>'naruto1.jpg'],
            ['cim'=>'One Piece 12. kötet','szerzo'=>'Eiichiro Oda','kategoria'=>'Manga','kiado'=>'Shueisha','ar'=>3290,'keszlet'=>15,'borito_kep'=>'onepiece12.jpg'],
            ['cim'=>'Démonölő 4. kötet','szerzo'=>'Koyoharu Gotouge','kategoria'=>'Manga','kiado'=>'Shueisha','ar'=>3490,'keszlet'=>10,'borito_kep'=>'demonolo4.jpg'],
            ['cim'=>'Attack on Titan 3. kötet','szerzo'=>'Hajime Isayama','kategoria'=>'Manga','kiado'=>'Kodansha','ar'=>3790,'keszlet'=>12,'borito_kep'=>'aot3.jpg'],
            ['cim'=>'My Hero Academia 7. kötet','szerzo'=>'Kohei Horikoshi','kategoria'=>'Manga','kiado'=>'Shueisha','ar'=>3590,'keszlet'=>18,'borito_kep'=>'mha7.jpg'],
            ['cim'=>'Batman: Killing Joke','szerzo'=>'Alan Moore','kategoria'=>'Comic','kiado'=>'DC Comics','ar'=>5990,'keszlet'=>5,'borito_kep'=>'killing_joke.jpg'],
            ['cim'=>'Superman: Red Son','szerzo'=>'Mark Millar','kategoria'=>'Comic','kiado'=>'DC Comics','ar'=>5490,'keszlet'=>7,'borito_kep'=>'red_son.jpg'],
        ]);

        DB::table('rendelesek')->insert([
            ['felhasznalo_id'=>1,'fizetesi_mod'=>'Bankkártya','szallitasi_cim'=>'Budapest, Andrássy út 14.'],
            ['felhasznalo_id'=>3,'fizetesi_mod'=>'Utánvét','szallitasi_cim'=>'Győr, Bajcsy-Zsilinszky út 55.'],
            ['felhasznalo_id'=>2,'fizetesi_mod'=>'PayPal','szallitasi_cim'=>'Pécs, Király utca 8.'],
            ['felhasznalo_id'=>4,'fizetesi_mod'=>'Bankkártya','szallitasi_cim'=>'Szeged, Fő tér 22.'],
        ]);

        DB::table('rendeles_tetelek')->insert([
            ['rendeles_id'=>1,'termek_id'=>1,'mennyiseg'=>2,'egysegar'=>2990],
            ['rendeles_id'=>1,'termek_id'=>6,'mennyiseg'=>1,'egysegar'=>5990],
            ['rendeles_id'=>2,'termek_id'=>3,'mennyiseg'=>1,'egysegar'=>3490],
            ['rendeles_id'=>3,'termek_id'=>5,'mennyiseg'=>3,'egysegar'=>3590],
            ['rendeles_id'=>4,'termek_id'=>2,'mennyiseg'=>1,'egysegar'=>3290],
            ['rendeles_id'=>4,'termek_id'=>7,'mennyiseg'=>1,'egysegar'=>5490],
        ]);
        
        DB::table('ertekelesek')->insert([
            ['felhasznalo_id'=>1,'termek_id'=>1,'ertekeles'=>5,'szoveg'=>'Nagyon jó kezdés, izgalmas sztori.'],
            ['felhasznalo_id'=>2,'termek_id'=>2,'ertekeles'=>4,'szoveg'=>'One Piece mindig hozza a szintet!'],
            ['felhasznalo_id'=>3,'termek_id'=>3,'ertekeles'=>5,'szoveg'=>'A Démonölő széria csúcsminőség!'],
            ['felhasznalo_id'=>4,'termek_id'=>4,'ertekeles'=>5,'szoveg'=>'Attack on Titan elképesztően jó!'],
            ['felhasznalo_id'=>1,'termek_id'=>6,'ertekeles'=>3,'szoveg'=>'Jó, de túl rövid volt.'],
        ]);

        DB::table('kreditek')->insert([
            ['felhasznalo_id'=>1,'egyenleg'=>100],
            ['felhasznalo_id'=>2,'egyenleg'=>240],
            ['felhasznalo_id'=>3,'egyenleg'=>80],
            ['felhasznalo_id'=>4,'egyenleg'=>150],
            ['felhasznalo_id'=>5,'egyenleg'=>60],
        ]);
    }
}
